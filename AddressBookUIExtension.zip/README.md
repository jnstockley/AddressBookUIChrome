# AddressBookUIChrome
Verison 2.0 has been released!

This is the biggest update since I have release the first address book!

## Key Features
 - Updated to match current version of Address Book UI
 
 ## How to Set Up your own server!
  If you want to create your own server please read the README on the AddressBookUI repository
  
 ## How to use my server!
  Download the extension from either the Chrome Webstore or load the unpacked extension that is posted under releases!
  
 ## Found a bug!
  Please report the bug under the issues tab with the bug label or tweet me on twitter @jackstockley_
 
 ## Have a question?
  You can leave questions under the issues tab with the question lable or tweet me on twitter @jackstockley_
  
 ## Commonly Asked Questions?
  - How do I run the chrome extension?
    - You can either download the chrome extenstion from the chrome webstore of you load the unpacked version into chrome will can be downloaded under the releases tab
 
 - What operating systems are supported?
   - Any version of chrome or chromium based browser that allows you to install extenstions
   
- When will the REST and CLI versions of this be updated?
  - All version are upadated and running! You can check them out on my profile home page!
  
- Will you continue to update this software with new features and bug fixes?
  - Yes of course, I do still have some features I plan on adding at some point. Right now I am planning on updating the backend on both the REST interface and CLI and converting the CLI into a maven project
  
- Do you have documention on the code?
  - For this project not at the moment. All the source code that runs the project is public! I plan on adding comments at a later date to help with understanding!
